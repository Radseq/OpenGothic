# SQLite `experience_next` runtime fix

## Cause

`mmo_unit_stat_sheet_current` and `mmo_save_slot_unit_stat_sheet` already contain schema 25 columns:

- `experience_next`
- `learning_points`
- `permanent_attitude`
- `temporary_attitude`

But the temporary runtime view `v_mmo_unit_stat_sheet` did not expose those columns. Later bootstrap/materialization SQL inserted from `v_mmo_unit_stat_sheet` using those column names, so SQLite reported:

```text
mmo sqlite exec failed: no such column: experience_next
```

This can happen even on a fresh database.

## Fix

`game/game/mmoruntimesqlite.cpp` now adds the missing four aggregate columns to `v_mmo_unit_stat_sheet`, using `runtime_npc_stats` as the normalized source.
