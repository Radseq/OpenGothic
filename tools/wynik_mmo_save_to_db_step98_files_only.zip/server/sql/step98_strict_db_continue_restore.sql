-- Step98: strict DB-native Continue/restore validation.
--
-- Step97 made the latest DB save checkpoint a bootstrap source. Step98 adds a
-- strict validation surface so local tests can prove that Continue/bootstrap is
-- actually restored from DB checkpoint snapshots and not silently falling back to
-- current projections or a local native .sav.

SET NAMES utf8mb4 COLLATE utf8mb4_0900_ai_ci;

DROP FUNCTION IF EXISTS mmo_validate_latest_save_checkpoint_restore_v1;
DELIMITER ;;
CREATE FUNCTION mmo_validate_latest_save_checkpoint_restore_v1(
  p_session_id BINARY(16)
) RETURNS LONGTEXT CHARACTER SET utf8mb4
NOT DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE v_manifest_id BINARY(16) DEFAULT NULL;
  DECLARE v_character_id BINARY(16) DEFAULT NULL;
  DECLARE v_world_instance_id BINARY(16) DEFAULT NULL;
  DECLARE v_manifest_uuid VARCHAR(36) DEFAULT NULL;
  DECLARE v_session_uuid VARCHAR(36) DEFAULT NULL;
  DECLARE v_character_key VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL;
  DECLARE v_save_key VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL;
  DECLARE v_display_name VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL;
  DECLARE v_client_world_name VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL;
  DECLARE v_created_at VARCHAR(64) DEFAULT NULL;
  DECLARE v_character_rows BIGINT DEFAULT 0;
  DECLARE v_inventory_rows BIGINT DEFAULT 0;
  DECLARE v_equipment_rows BIGINT DEFAULT 0;
  DECLARE v_quest_rows BIGINT DEFAULT 0;
  DECLARE v_known_dialog_rows BIGINT DEFAULT 0;
  DECLARE v_script_state_rows BIGINT DEFAULT 0;
  DECLARE v_world_entity_rows BIGINT DEFAULT 0;
  DECLARE v_world_inventory_rows BIGINT DEFAULT 0;
  DECLARE v_world_clock_rows BIGINT DEFAULT 0;
  DECLARE v_mover_rows BIGINT DEFAULT 0;
  DECLARE v_export_json LONGTEXT CHARACTER SET utf8mb4 DEFAULT NULL;
  DECLARE v_exported_bytes BIGINT DEFAULT 0;
  DECLARE v_export_schema VARCHAR(191) DEFAULT NULL;
  DECLARE v_export_source VARCHAR(191) DEFAULT NULL;
  DECLARE v_strict_ok BOOL DEFAULT FALSE;
  DECLARE v_not_found BOOL DEFAULT FALSE;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_not_found = TRUE;

  SET v_session_uuid = BIN_TO_UUID(p_session_id, 1);

  SELECT sm.manifest_id,
         sm.character_id,
         sm.world_instance_id,
         BIN_TO_UUID(sm.manifest_id,1),
         c.character_key,
         COALESCE(sm.save_slot_key, sm.manifest_key),
         sm.display_name,
         sm.client_world_name,
         DATE_FORMAT(sm.created_at,'%Y-%m-%dT%H:%i:%s.%fZ')
    INTO v_manifest_id,
         v_character_id,
         v_world_instance_id,
         v_manifest_uuid,
         v_character_key,
         v_save_key,
         v_display_name,
         v_client_world_name,
         v_created_at
    FROM server_sessions ss
    JOIN mmo_save_checkpoint_manifests sm
      ON sm.character_id = ss.character_id
     AND sm.world_instance_id = ss.world_instance_id
    JOIN characters c ON c.character_id = sm.character_id
   WHERE ss.session_id = p_session_id
   ORDER BY sm.created_at DESC, sm.row_version DESC
   LIMIT 1;

  IF v_not_found OR v_manifest_id IS NULL THEN
    RETURN JSON_OBJECT(
      'strict_restore_ok', false,
      'has_checkpoint', false,
      'reason', 'no_db_save_checkpoint_for_session',
      'session_uuid', v_session_uuid,
      'snapshot_source', NULL,
      'exported_bootstrap_bytes', 0
    );
  END IF;

  SELECT COUNT(*) INTO v_character_rows
    FROM mmo_save_checkpoint_character_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_inventory_rows
    FROM mmo_save_checkpoint_inventory_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_equipment_rows
    FROM mmo_save_checkpoint_equipment_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_quest_rows
    FROM mmo_save_checkpoint_quest_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_known_dialog_rows
    FROM mmo_save_checkpoint_known_dialog_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_script_state_rows
    FROM mmo_save_checkpoint_script_state_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_world_entity_rows
    FROM mmo_save_checkpoint_world_entity_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_world_inventory_rows
    FROM mmo_save_checkpoint_world_inventory_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_world_clock_rows
    FROM mmo_save_checkpoint_world_clock_snapshot
   WHERE manifest_id = v_manifest_id;

  SELECT COUNT(*) INTO v_mover_rows
    FROM mmo_save_checkpoint_mover_snapshot
   WHERE manifest_id = v_manifest_id;

  SET v_export_json = mmo_build_latest_save_checkpoint_bootstrap_snapshot_v1(p_session_id);
  SET v_exported_bytes = COALESCE(CHAR_LENGTH(v_export_json), 0);

  IF v_export_json IS NOT NULL AND v_exported_bytes > 0 AND JSON_VALID(v_export_json) THEN
    SET v_export_schema = JSON_UNQUOTE(JSON_EXTRACT(v_export_json, '$.schema'));
    SET v_export_source = JSON_UNQUOTE(JSON_EXTRACT(v_export_json, '$.snapshot_source'));
  END IF;

  SET v_strict_ok = (
    v_character_rows = 1
    AND v_world_entity_rows > 0
    AND v_exported_bytes > 1000
    AND v_export_schema = 'mmo_bootstrap_snapshot_v1'
    AND v_export_source = 'db_save_checkpoint_v1'
  );

  RETURN JSON_OBJECT(
    'strict_restore_ok', v_strict_ok,
    'has_checkpoint', true,
    'reason', IF(v_strict_ok, 'ok', 'checkpoint_export_is_not_strictly_restore_ready'),
    'session_uuid', v_session_uuid,
    'manifest_uuid', v_manifest_uuid,
    'character_key', v_character_key,
    'save_key', v_save_key,
    'display_name', v_display_name,
    'client_world_name', v_client_world_name,
    'created_at', v_created_at,
    'snapshot_source', v_export_source,
    'schema', v_export_schema,
    'exported_bootstrap_bytes', v_exported_bytes,
    'character_rows', v_character_rows,
    'inventory_rows', v_inventory_rows,
    'equipment_rows', v_equipment_rows,
    'quest_rows', v_quest_rows,
    'known_dialog_rows', v_known_dialog_rows,
    'script_state_rows', v_script_state_rows,
    'world_entity_rows', v_world_entity_rows,
    'world_inventory_rows', v_world_inventory_rows,
    'world_clock_rows', v_world_clock_rows,
    'mover_rows', v_mover_rows
  );
END ;;
DELIMITER ;

DROP PROCEDURE IF EXISTS mmo_assert_latest_save_checkpoint_restore_v1;
DELIMITER ;;
CREATE PROCEDURE mmo_assert_latest_save_checkpoint_restore_v1(
  IN p_session_id BINARY(16),
  OUT p_validation_json LONGTEXT CHARACTER SET utf8mb4
)
BEGIN
  SET p_validation_json = mmo_validate_latest_save_checkpoint_restore_v1(p_session_id);

  IF COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p_validation_json, '$.strict_restore_ok')), 'false') <> 'true' THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT='mmo_assert_latest_save_checkpoint_restore_v1: latest DB save checkpoint is not strict-restore ready';
  END IF;
END ;;
DELIMITER ;

CREATE OR REPLACE VIEW v_mmo_latest_save_checkpoint_strict_restore AS
SELECT
  BIN_TO_UUID(ss.session_id,1) AS session_uuid,
  ss.session_key,
  c.character_key,
  JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.manifest_uuid')) AS manifest_uuid,
  JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.save_key')) AS save_key,
  JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.snapshot_source')) AS snapshot_source,
  JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.strict_restore_ok') AS strict_restore_ok,
  CAST(JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.exported_bootstrap_bytes')) AS UNSIGNED) AS exported_bootstrap_bytes,
  CAST(JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.character_rows')) AS UNSIGNED) AS character_rows,
  CAST(JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.inventory_rows')) AS UNSIGNED) AS inventory_rows,
  CAST(JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.known_dialog_rows')) AS UNSIGNED) AS known_dialog_rows,
  CAST(JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.script_state_rows')) AS UNSIGNED) AS script_state_rows,
  CAST(JSON_UNQUOTE(JSON_EXTRACT(mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id), '$.world_entity_rows')) AS UNSIGNED) AS world_entity_rows,
  mmo_validate_latest_save_checkpoint_restore_v1(ss.session_id) AS validation_json,
  ss.updated_at AS session_updated_at
FROM server_sessions ss
JOIN characters c ON c.character_id = ss.character_id;
